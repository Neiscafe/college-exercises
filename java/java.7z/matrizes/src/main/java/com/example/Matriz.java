package com.example;

public class Matriz {
    private int[][] matriz;

    public Matriz(int[][] matriz){
        this.matriz = matriz;
    }

    public void setMatriz(int[][] matriz) {
        this.matriz = matriz;
    }

    public int[][] getMatriz() {
        return matriz;
    }
}
