numeros_pares = []
atual = 0

for atual in range(0, 21, 2):
    numeros_pares.append(atual)

print("Os primeiros 10 números pares são:", numeros_pares)