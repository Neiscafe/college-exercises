lista = [1.4, 10.0, 9.8, 7.5]
print(sum(lista)/len(lista))
print(max(lista))
print(min(lista))