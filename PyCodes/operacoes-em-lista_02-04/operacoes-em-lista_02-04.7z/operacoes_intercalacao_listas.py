lista1 = [1,3,5]
lista2= [2,4,6]
res = list(set(lista1).union(lista2))
print(res)
