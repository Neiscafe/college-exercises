multiplos_de_5 = []
for numero in range(1, 51):
    if numero % 5 == 0:
        multiplos_de_5.append(numero)

print(multiplos_de_5)