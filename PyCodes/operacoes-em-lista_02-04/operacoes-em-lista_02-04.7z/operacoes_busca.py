lista = ["Banana", "Maçã", "Abacate", "Uva"]
if lista.__contains__("Maçã"):
    print("A maçã está presente!")
else:
    print("A maçã não está presente!")
print(lista.index("Uva"))