lista1 = [x for x in range(1,6)]
lista2 = [x for x in range(6,11)]
print(lista1+lista2)
print((lista1+lista2)[2:])