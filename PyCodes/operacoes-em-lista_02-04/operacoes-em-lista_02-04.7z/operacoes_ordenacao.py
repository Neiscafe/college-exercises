lista = ["Alice", "Bob", "Charlie", "David", "Eva"]
print(sorted(lista))
print(sorted(lista, reverse=True))