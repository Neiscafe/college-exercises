lista = [x for x in range(1,6)]
print(lista)
lista.append(6)
print(lista)
lista.remove(3)
print(lista)